/**
 * DraftDiffModal.jsx - Модальное окно сравнения черновика с сервером
 * 
 * Отображает различия в двух колонках (как git diff):
 * - Левая: Данные с сервера
 * - Правая: Данные из черновика
 * 
 * Пользователь может:
 * - Применить все изменения из черновика
 * - Выборочно применить изменения
 * - Отменить черновик
 */

import React, { useState, useMemo } from 'react';
import { 
  Modal, Button, Tabs, Tag, Space, Checkbox, 
  Typography, Empty, Tooltip, Divider 
} from 'antd';
import { 
  PlusCircleOutlined, 
  EditOutlined, 
  DeleteOutlined,
  SwapOutlined,
  CheckOutlined,
  CloseOutlined,
} from '@ant-design/icons';
import dayjs from 'dayjs';

import './style/draft-diff-modal.css';

const { Text, Title } = Typography;

/**
 * Метки вкладок
 */
const TAB_LABELS = {
  notes: 'Заметки',
  projects: 'Проекты',
  calls: 'Звонки/Встречи',
  main: 'Основная информация',
};

/**
 * Метки полей
 */
const FIELD_LABELS = {
  // Notes
  theme: 'Тема',
  notes: 'Текст заметки',
  // Projects
  name: 'Название',
  equipment: 'Оборудование',
  customer: 'Заказчик',
  address: 'Адрес',
  stage: 'Этап',
  contactperson: 'Контактное лицо',
  cost: 'Стоимость',
  bonus: 'Бонус',
  comment: 'Комментарий',
  typepaec: 'Тип СОУЭ',
  erector_id: 'Монтажник',
  date: 'Дата начала',
  date_end: 'Дата окончания',
  // Calls
  result: 'Результат',
  type: 'Тип',
  // Common
  deleted: 'Удалено',
};

const DraftDiffModal = ({
  visible,
  onClose,
  diffResult,
  draftData,
  serverData,
  onApplyAll,
  onApplySelected,
  onDiscard,
}) => {
  // Состояние выбранных изменений
  const [selectedChanges, setSelectedChanges] = useState({});

  // Вкладки с изменениями
  const tabsWithChanges = useMemo(() => {
    if (!diffResult?.tabs) return [];
    
    return Object.entries(diffResult.tabs)
      .filter(([_, data]) => data.hasDifferences)
      .map(([key, data]) => ({
        key,
        label: TAB_LABELS[key] || key,
        data,
        badge: getBadgeCount(data),
      }));
  }, [diffResult]);

  // Подсчёт изменений для бейджа
  function getBadgeCount(tabData) {
    return (tabData.added?.length || 0) + 
           (tabData.modified?.length || 0) + 
           (tabData.deleted?.length || 0);
  }

  // Переключение выбора элемента
  const toggleSelection = (tabKey, itemId, type) => {
    setSelectedChanges(prev => {
      const tabChanges = prev[tabKey] || {};
      const typeChanges = tabChanges[type] || [];
      
      const isSelected = typeChanges.includes(itemId);
      
      return {
        ...prev,
        [tabKey]: {
          ...tabChanges,
          [type]: isSelected 
            ? typeChanges.filter(id => id !== itemId)
            : [...typeChanges, itemId],
        },
      };
    });
  };

  // Выбрать все изменения во вкладке
  const selectAllInTab = (tabKey, tabData) => {
    const allIds = {
      added: (tabData.added || []).map(item => item.id),
      modified: (tabData.modified || []).map(item => item.id),
      deleted: (tabData.deleted || []).map(item => item.id),
    };

    setSelectedChanges(prev => ({
      ...prev,
      [tabKey]: allIds,
    }));
  };

  // Снять выбор со всех во вкладке
  const deselectAllInTab = (tabKey) => {
    setSelectedChanges(prev => ({
      ...prev,
      [tabKey]: {},
    }));
  };

  // Проверка выбран ли элемент
  const isSelected = (tabKey, itemId, type) => {
    return selectedChanges[tabKey]?.[type]?.includes(itemId) || false;
  };

  // Есть ли выбранные элементы
  const hasSelectedChanges = useMemo(() => {
    return Object.values(selectedChanges).some(tab => 
      Object.values(tab).some(arr => arr.length > 0)
    );
  }, [selectedChanges]);

  // Форматирование значения для отображения
  const formatValue = (value, field) => {
    if (value === null || value === undefined || value === '') {
      return <Text type="secondary" italic>пусто</Text>;
    }

    if (field === 'deleted') {
      return value ? <Tag color="red">Да</Tag> : <Tag color="green">Нет</Tag>;
    }

    if (field === 'date' || field === 'date_end') {
      const d = dayjs(value);
      return d.isValid() ? d.format('DD.MM.YYYY') : String(value);
    }

    if (typeof value === 'object') {
      return JSON.stringify(value);
    }

    return String(value);
  };

  // Получить заголовок элемента
  const getItemTitle = (item, tabKey) => {
    switch (tabKey) {
      case 'notes':
        return item.theme || 'Без темы';
      case 'projects':
        return item.name || 'Без названия';
      case 'calls':
        return item.theme || 'Без темы';
      default:
        return `ID: ${item.id}`;
    }
  };

  // Рендер добавленных элементов
  const renderAddedItems = (items, tabKey) => {
    if (!items || items.length === 0) return null;

    return (
      <div className="diff-section">
        <div className="diff-section-header">
          <PlusCircleOutlined style={{ color: '#52c41a' }} />
          <span>Новые записи ({items.length})</span>
        </div>
        
        {items.map(item => (
          <div 
            key={item.id} 
            className={`diff-item diff-item-added ${isSelected(tabKey, item.id, 'added') ? 'selected' : ''}`}
          >
            <Checkbox
              checked={isSelected(tabKey, item.id, 'added')}
              onChange={() => toggleSelection(tabKey, item.id, 'added')}
            >
              <span className="diff-item-title">{getItemTitle(item, tabKey)}</span>
            </Checkbox>
            
            <div className="diff-item-preview">
              {Object.entries(item)
                .filter(([key]) => !['id', 'command', 'creator', 'curator', 'author'].includes(key))
                .slice(0, 3)
                .map(([key, value]) => (
                  <div key={key} className="diff-field-preview">
                    <Text type="secondary">{FIELD_LABELS[key] || key}:</Text>
                    <Text>{formatValue(value, key)}</Text>
                  </div>
                ))
              }
            </div>
          </div>
        ))}
      </div>
    );
  };

  // Рендер изменённых элементов
  const renderModifiedItems = (items, tabKey) => {
    if (!items || items.length === 0) return null;

    return (
      <div className="diff-section">
        <div className="diff-section-header">
          <EditOutlined style={{ color: '#faad14' }} />
          <span>Изменённые записи ({items.length})</span>
        </div>
        
        {items.map(({ id, draft, server, changes }) => (
          <div 
            key={id} 
            className={`diff-item diff-item-modified ${isSelected(tabKey, id, 'modified') ? 'selected' : ''}`}
          >
            <Checkbox
              checked={isSelected(tabKey, id, 'modified')}
              onChange={() => toggleSelection(tabKey, id, 'modified')}
            >
              <span className="diff-item-title">{getItemTitle(draft, tabKey)}</span>
              <Tag color="orange" style={{ marginLeft: 8 }}>
                {changes.length} изменений
              </Tag>
            </Checkbox>
            
            <div className="diff-comparison">
              {changes.map(({ field, draftValue, serverValue }) => (
                <div key={field} className="diff-field-row">
                  <div className="diff-field-label">
                    {FIELD_LABELS[field] || field}
                  </div>
                  <div className="diff-field-values">
                    <div className="diff-value diff-value-server">
                      <Text type="secondary">Сервер:</Text>
                      <div className="diff-value-content">
                        {formatValue(serverValue, field)}
                      </div>
                    </div>
                    <SwapOutlined className="diff-arrow" />
                    <div className="diff-value diff-value-draft">
                      <Text type="secondary">Черновик:</Text>
                      <div className="diff-value-content diff-value-highlight">
                        {formatValue(draftValue, field)}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    );
  };

  // Рендер вкладки
  const renderTabContent = (tabKey, tabData) => {
    const hasItems = 
      (tabData.added?.length > 0) || 
      (tabData.modified?.length > 0) || 
      (tabData.deleted?.length > 0);

    if (!hasItems) {
      return <Empty description="Нет изменений" />;
    }

    return (
      <div className="diff-tab-content">
        <div className="diff-tab-actions">
          <Button 
            size="small" 
            onClick={() => selectAllInTab(tabKey, tabData)}
          >
            Выбрать все
          </Button>
          <Button 
            size="small" 
            onClick={() => deselectAllInTab(tabKey)}
          >
            Снять выбор
          </Button>
        </div>

        {renderAddedItems(tabData.added, tabKey)}
        {renderModifiedItems(tabData.modified, tabKey)}
        
        {/* TODO: renderDeletedItems */}
      </div>
    );
  };

  // Если нет изменений
  if (!diffResult?.hasDifferences) {
    return (
      <Modal
        open={visible}
        title="Сравнение данных"
        onCancel={onClose}
        footer={[
          <Button key="close" onClick={onClose}>
            Закрыть
          </Button>
        ]}
      >
        <Empty description="Черновик идентичен данным на сервере" />
      </Modal>
    );
  }

  return (
    <Modal
      open={visible}
      title={
        <Space>
          <SwapOutlined />
          <span>Сравнение черновика с сервером</span>
        </Space>
      }
      width={900}
      onCancel={onClose}
      className="draft-diff-modal"
      footer={[
        <Button 
          key="discard" 
          danger 
          icon={<CloseOutlined />}
          onClick={onDiscard}
        >
          Удалить черновик
        </Button>,
        <Button 
          key="apply-selected" 
          icon={<CheckOutlined />}
          disabled={!hasSelectedChanges}
          onClick={() => onApplySelected(selectedChanges)}
        >
          Применить выбранное
        </Button>,
        <Button 
          key="apply-all" 
          type="primary" 
          icon={<CheckOutlined />}
          onClick={onApplyAll}
        >
          Применить всё из черновика
        </Button>,
      ]}
    >
      {/* Информационная панель */}
      <div className="diff-info-panel">
        <div className="diff-info-item">
          <Text type="secondary">Черновик сохранён:</Text>
          <Text strong>
            {draftData?.updatedAt 
              ? dayjs(draftData.updatedAt).format('DD.MM.YYYY HH:mm:ss')
              : '—'
            }
          </Text>
        </div>
        <Divider type="vertical" />
        <div className="diff-info-item">
          <Text type="secondary">Всего изменений:</Text>
          <Text strong>
            {tabsWithChanges.reduce((sum, tab) => sum + tab.badge, 0)}
          </Text>
        </div>
      </div>

      {/* Вкладки с изменениями */}
      <Tabs
        items={tabsWithChanges.map(tab => ({
          key: tab.key,
          label: (
            <span>
              {tab.label}
              <Tag color="blue" style={{ marginLeft: 8 }}>
                {tab.badge}
              </Tag>
            </span>
          ),
          children: renderTabContent(tab.key, tab.data),
        }))}
      />
    </Modal>
  );
};

export default DraftDiffModal;
