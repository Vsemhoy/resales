/**
 * useDraftSync.js - Хук для синхронизации черновиков
 * 
 * Функции:
 * - Автосохранение черновика при изменениях
 * - Проверка наличия черновика при загрузке
 * - Обработка офлайн/онлайн режима
 * - Периодическая проверка доступности сервера
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { message, Modal } from 'antd';
import draftManager from './DraftManager';

// Константы
const AUTOSAVE_DELAY = 2000;        // Задержка автосохранения (ms)
const RECONNECT_INTERVAL = 60000;   // Интервал проверки сети (ms)

/**
 * Состояния синхронизации
 */
export const SYNC_STATUS = {
  IDLE: 'idle',                     // Ничего не происходит
  LOADING: 'loading',               // Загрузка данных
  SAVING_DRAFT: 'saving_draft',     // Сохранение черновика
  DRAFT_FOUND: 'draft_found',       // Найден черновик
  OFFLINE: 'offline',               // Нет сети
  OFFLINE_DRAFT: 'offline_draft',   // Офлайн режим с драфтом
  RECONNECTING: 'reconnecting',     // Попытка переподключения
  RECONNECTED: 'reconnected',       // Сеть восстановлена
  ERROR: 'error',                   // Ошибка
};

/**
 * Хук для синхронизации черновиков
 * 
 * @param {object} options
 * @param {number} options.orgId - ID организации
 * @param {object} options.forms - Объект с формами { notes, projects, calls, main }
 * @param {Function} options.loadServerData - Функция загрузки данных с сервера
 * @param {Function} options.onDraftConflict - Callback при обнаружении конфликта
 */
export const useDraftSync = ({
  orgId,
  forms,
  loadServerData,
  onDraftConflict,
}) => {
  // Состояния
  const [syncStatus, setSyncStatus] = useState(SYNC_STATUS.IDLE);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [hasDraft, setHasDraft] = useState(false);
  const [draftData, setDraftData] = useState(null);
  const [serverData, setServerData] = useState(null);
  const [diffResult, setDiffResult] = useState(null);
  const [isOfflineMode, setIsOfflineMode] = useState(false);

  // Refs
  const autosaveTimerRef = useRef(null);
  const reconnectTimerRef = useRef(null);
  const lastSavedDataRef = useRef(null);

  // ===================== ИНИЦИАЛИЗАЦИЯ =====================

  useEffect(() => {
    draftManager.init();
    
    // Подписка на изменение статуса сети
    const unsubscribe = draftManager.onNetworkChange((online) => {
      setIsOnline(online);
      
      if (online && isOfflineMode) {
        // Сеть восстановилась
        handleNetworkRestored();
      } else if (!online) {
        // Сеть пропала
        handleNetworkLost();
      }
    });

    return () => {
      unsubscribe();
      clearTimers();
    };
  }, []);

  // ===================== ЗАГРУЗКА ДАННЫХ =====================

  /**
   * Основная функция загрузки данных
   * Проверяет наличие черновика и статус сети
   */
  const initializeData = useCallback(async () => {
    if (!orgId) return;

    setSyncStatus(SYNC_STATUS.LOADING);

    try {
      // 1. Проверяем наличие черновика
      const draft = await draftManager.getDraft(orgId);
      
      // 2. Проверяем доступность сети
      if (!navigator.onLine) {
        // Офлайн режим
        if (draft) {
          setDraftData(draft);
          setHasDraft(true);
          setSyncStatus(SYNC_STATUS.OFFLINE);
          
          // Предлагаем загрузить драфт
          showOfflineDraftPrompt(draft);
        } else {
          setSyncStatus(SYNC_STATUS.OFFLINE);
          message.warning('Нет соединения с сервером. Данные недоступны.');
        }
        return;
      }

      // 3. Загружаем данные с сервера
      const serverResult = await loadServerData();
      setServerData(serverResult);

      // 4. Если есть черновик — сравниваем
      if (draft) {
        const comparison = draftManager.compareDraftWithServer(
          draft.data,
          serverResult
        );

        if (comparison.hasDifferences) {
          setDraftData(draft);
          setDiffResult(comparison);
          setHasDraft(true);
          setSyncStatus(SYNC_STATUS.DRAFT_FOUND);
          
          // Вызываем callback для показа UI
          onDraftConflict?.({
            draft,
            serverData: serverResult,
            comparison,
          });
        } else {
          // Черновик идентичен серверу — удаляем
          await draftManager.deleteDraft(orgId);
          setSyncStatus(SYNC_STATUS.IDLE);
        }
      } else {
        setSyncStatus(SYNC_STATUS.IDLE);
      }

    } catch (error) {
      console.error('[useDraftSync] Ошибка инициализации:', error);
      setSyncStatus(SYNC_STATUS.ERROR);
      
      // Пробуем загрузить черновик
      const draft = await draftManager.getDraft(orgId);
      if (draft) {
        setDraftData(draft);
        setHasDraft(true);
        showOfflineDraftPrompt(draft);
      }
    }
  }, [orgId, loadServerData, onDraftConflict]);

  // ===================== АВТОСОХРАНЕНИЕ ЧЕРНОВИКА =====================

  /**
   * Сохраняет текущее состояние форм как черновик
   */
  const saveDraft = useCallback(async () => {
    if (!orgId || !forms) return;

    const currentData = collectFormsData();
    
    // Проверяем, изменились ли данные
    if (JSON.stringify(currentData) === JSON.stringify(lastSavedDataRef.current)) {
      return; // Данные не изменились
    }

    try {
      setSyncStatus(SYNC_STATUS.SAVING_DRAFT);
      
      await draftManager.saveDraft(
        orgId,
        currentData,
        serverData?.updatedAt || null
      );
      
      lastSavedDataRef.current = currentData;
      setHasDraft(true);
      
      setSyncStatus(isOfflineMode ? SYNC_STATUS.OFFLINE_DRAFT : SYNC_STATUS.IDLE);
      
    } catch (error) {
      console.error('[useDraftSync] Ошибка сохранения черновика:', error);
    }
  }, [orgId, forms, serverData, isOfflineMode]);

  /**
   * Запускает отложенное автосохранение
   */
  const scheduleDraftSave = useCallback(() => {
    if (autosaveTimerRef.current) {
      clearTimeout(autosaveTimerRef.current);
    }

    autosaveTimerRef.current = setTimeout(() => {
      saveDraft();
    }, AUTOSAVE_DELAY);
  }, [saveDraft]);

  /**
   * Собирает данные со всех форм
   */
  const collectFormsData = useCallback(() => {
    const data = {};

    if (forms.notes) {
      data.notes = forms.notes.getFieldsValue();
    }
    if (forms.projects) {
      data.projects = forms.projects.getFieldsValue();
    }
    if (forms.calls) {
      data.calls = forms.calls.getFieldsValue();
    }
    if (forms.main) {
      data.main = forms.main.getFieldsValue();
    }

    return data;
  }, [forms]);

  // ===================== ПРИМЕНЕНИЕ ЧЕРНОВИКА =====================

  /**
   * Загружает черновик в формы
   */
  const applyDraft = useCallback(() => {
    if (!draftData?.data) return;

    const { data } = draftData;

    if (data.notes && forms.notes) {
      forms.notes.setFieldsValue(data.notes);
    }
    if (data.projects && forms.projects) {
      forms.projects.setFieldsValue(data.projects);
    }
    if (data.calls && forms.calls) {
      forms.calls.setFieldsValue(data.calls);
    }
    if (data.main && forms.main) {
      forms.main.setFieldsValue(data.main);
    }

    message.success('Черновик загружен');
    
    if (isOfflineMode) {
      setSyncStatus(SYNC_STATUS.OFFLINE_DRAFT);
    } else {
      setSyncStatus(SYNC_STATUS.IDLE);
    }
  }, [draftData, forms, isOfflineMode]);

  /**
   * Применяет выбранные изменения из черновика
   * @param {object} selectedChanges - Выбранные изменения по вкладкам
   */
  const applySelectedChanges = useCallback((selectedChanges) => {
    if (!draftData?.data) return;

    Object.keys(selectedChanges).forEach(tabKey => {
      const changes = selectedChanges[tabKey];
      const form = forms[tabKey];
      
      if (!form || !changes) return;

      // Применяем изменения к форме
      // TODO: Реализовать детальное применение
    });

    message.success('Выбранные изменения применены');
    setSyncStatus(SYNC_STATUS.IDLE);
  }, [draftData, forms]);

  /**
   * Отменяет черновик
   */
  const discardDraft = useCallback(async () => {
    if (!orgId) return;

    try {
      await draftManager.deleteDraft(orgId);
      setDraftData(null);
      setHasDraft(false);
      setDiffResult(null);
      message.info('Черновик удалён');
      setSyncStatus(SYNC_STATUS.IDLE);
    } catch (error) {
      console.error('[useDraftSync] Ошибка удаления черновика:', error);
    }
  }, [orgId]);

  // ===================== ОБРАБОТКА СЕТИ =====================

  /**
   * Обработка потери сети
   */
  const handleNetworkLost = useCallback(() => {
    message.warning('Соединение с сервером потеряно');
    
    // Сохраняем текущие данные как черновик
    saveDraft();
    
    setIsOfflineMode(true);
    setSyncStatus(SYNC_STATUS.OFFLINE_DRAFT);
    
    // Запускаем периодическую проверку сети
    startReconnectPolling();
  }, [saveDraft]);

  /**
   * Обработка восстановления сети
   */
  const handleNetworkRestored = useCallback(async () => {
    stopReconnectPolling();
    setSyncStatus(SYNC_STATUS.RECONNECTED);
    
    message.success('Соединение восстановлено!');
    
    // Проверяем, есть ли несохранённые данные
    const draft = await draftManager.getDraft(orgId);
    
    if (draft) {
      // Загружаем свежие данные с сервера для сравнения
      try {
        const freshServerData = await loadServerData();
        const comparison = draftManager.compareDraftWithServer(
          draft.data,
          freshServerData
        );

        if (comparison.hasDifferences) {
          // Показываем выбор пользователю
          Modal.confirm({
            title: 'Сервер снова доступен!',
            content: 'У вас есть несохранённые изменения. Что вы хотите сделать?',
            okText: 'Сохранить на сервер',
            cancelText: 'Сравнить данные',
            onOk: () => {
              // TODO: Сохранить на сервер
            },
            onCancel: () => {
              setServerData(freshServerData);
              setDiffResult(comparison);
              onDraftConflict?.({
                draft,
                serverData: freshServerData,
                comparison,
              });
            },
          });
        } else {
          setIsOfflineMode(false);
          setSyncStatus(SYNC_STATUS.IDLE);
        }
      } catch (error) {
        console.error('[useDraftSync] Ошибка при восстановлении:', error);
      }
    } else {
      setIsOfflineMode(false);
      setSyncStatus(SYNC_STATUS.IDLE);
    }
  }, [orgId, loadServerData, onDraftConflict]);

  /**
   * Запускает периодическую проверку сети
   */
  const startReconnectPolling = useCallback(() => {
    if (reconnectTimerRef.current) return;

    reconnectTimerRef.current = setInterval(async () => {
      if (!navigator.onLine) return;
      
      setSyncStatus(SYNC_STATUS.RECONNECTING);
      
      try {
        // Пробуем загрузить данные
        await loadServerData();
        // Если успешно — сеть восстановлена
        handleNetworkRestored();
      } catch {
        // Сервер всё ещё недоступен
        setSyncStatus(SYNC_STATUS.OFFLINE_DRAFT);
      }
    }, RECONNECT_INTERVAL);
  }, [loadServerData, handleNetworkRestored]);

  /**
   * Останавливает проверку сети
   */
  const stopReconnectPolling = useCallback(() => {
    if (reconnectTimerRef.current) {
      clearInterval(reconnectTimerRef.current);
      reconnectTimerRef.current = null;
    }
  }, []);

  // ===================== ХЕЛПЕРЫ =====================

  /**
   * Показывает промпт для офлайн режима
   */
  const showOfflineDraftPrompt = useCallback((draft) => {
    const updatedAt = new Date(draft.updatedAt).toLocaleString('ru-RU');
    
    Modal.confirm({
      title: 'Нет соединения с сервером',
      content: `Найдена последняя редактированная версия от ${updatedAt}. Загрузить её?`,
      okText: 'Загрузить',
      cancelText: 'Отмена',
      onOk: () => {
        setDraftData(draft);
        setIsOfflineMode(true);
        setSyncStatus(SYNC_STATUS.OFFLINE_DRAFT);
        
        // Применяем черновик
        applyDraft();
        
        message.warning('Вы работаете в офлайн режиме. Данные будут сохранены при восстановлении соединения.');
        
        // Запускаем проверку сети
        startReconnectPolling();
      },
      onCancel: () => {
        message.info('Данные недоступны без подключения к сети');
      },
    });
  }, [applyDraft, startReconnectPolling]);

  /**
   * Очищает таймеры
   */
  const clearTimers = useCallback(() => {
    if (autosaveTimerRef.current) {
      clearTimeout(autosaveTimerRef.current);
    }
    if (reconnectTimerRef.current) {
      clearInterval(reconnectTimerRef.current);
    }
  }, []);

  // ===================== ЭФФЕКТЫ =====================

  // Инициализация при изменении orgId
  useEffect(() => {
    if (orgId) {
      initializeData();
    }
    
    return () => {
      clearTimers();
    };
  }, [orgId]);

  // ===================== ВОЗВРАЩАЕМОЕ API =====================

  return {
    // Состояния
    syncStatus,
    isOnline,
    hasDraft,
    draftData,
    serverData,
    diffResult,
    isOfflineMode,

    // Методы
    initializeData,
    saveDraft,
    scheduleDraftSave,
    applyDraft,
    applySelectedChanges,
    discardDraft,

    // Хелперы
    collectFormsData,
  };
};

export default useDraftSync;
