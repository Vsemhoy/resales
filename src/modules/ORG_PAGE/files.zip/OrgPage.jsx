/**
 * OrgPage.jsx - Паспорт организации
 * 
 * Полная интеграция:
 * - Централизованное управление формами (useOrgPageForms)
 * - Черновики для офлайн-работы (DraftManager)
 * - Логирование изменений (FormLogger)
 * - Модальное окно сравнения (DraftDiffModal)
 */

import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import { Button, message, Modal, Affix, Tag, Tooltip, Spin } from 'antd';
import { 
  PencilIcon, 
  XMarkIcon, 
  ClipboardDocumentCheckIcon 
} from '@heroicons/react/24/outline';
import { LoadingOutlined, WifiOutlined, CloudOutlined } from '@ant-design/icons';

import { CSRF_TOKEN, PRODMODE } from '../../config/config';
import { PROD_AXIOS_INSTANCE } from '../../config/Api';

// Хук для управления формами
import { useOrgPageForms, SYNC_STATUS } from './components/forms/useOrgPageForms';

// Компоненты черновиков
import DraftStatusBanner from './components/forms/DraftStatusBanner';
import DraftDiffModal from './components/forms/DraftDiffModal';

// Формы вкладок
import NotesTabForm from './components/forms/NotesTabForm';
import ProjectsTabForm from './components/forms/ProjectsTabForm';
// import CallsTabForm from './components/forms/CallsTabForm';
// import MainTabForm from './components/forms/MainTabForm';

// Старые компоненты
import OrgListModalBillsTab from '../ORG_LIST/components/OrgModal/Tabs/OrgListModalBillsTab';
import OrgListModalOffersTab from '../ORG_LIST/components/OrgModal/Tabs/OrgListModalOffersTab';
import OrgListModalHistoryTab from '../ORG_LIST/components/OrgModal/Tabs/OrgListModalHistoryTab';

import './components/style/orgpage-forms.css';

const TAB_CONFIG = [
  { key: 'm', label: 'Основная информация' },
  { key: 'b', label: 'Счета' },
  { key: 'o', label: 'КП' },
  { key: 'p', label: 'Проекты' },
  { key: 'c', label: 'Встречи/Звонки' },
  { key: 'n', label: 'Заметки' },
  { key: 'h', label: 'История' },
];

const OrgPage = ({ userdata }) => {
  const { item_id } = useParams();
  const [searchParams, setSearchParams] = useSearchParams();

  // ===================== СОСТОЯНИЯ UI =====================
  const [orgId] = useState(item_id ? parseInt(item_id) : null);
  const [activeTab, setActiveTab] = useState(searchParams.get('tab') || 'm');
  const [editMode, setEditMode] = useState(false);
  const [saving, setSaving] = useState(false);
  const [orgName, setOrgName] = useState('');
  const [selects, setSelects] = useState(null);
  const [orgContacts, setOrgContacts] = useState([]);
  
  // Модальное окно сравнения черновиков
  const [diffModalVisible, setDiffModalVisible] = useState(false);

  // ===================== ЗАГРУЗКА ДАННЫХ С СЕРВЕРА =====================
  
  const loadServerData = useCallback(async () => {
    if (!orgId) return null;

    if (PRODMODE) {
      // Загружаем все данные параллельно
      const [notesRes, projectsRes, callsRes, mainRes] = await Promise.all([
        PROD_AXIOS_INSTANCE.post(`/api/sales/v2/orglist/${orgId}/n`, {
          data: { page: 1, limit: 50 },
          _token: CSRF_TOKEN,
        }),
        PROD_AXIOS_INSTANCE.post(`/api/sales/v2/orglist/${orgId}/p`, {
          data: { page: 1, limit: 50 },
          _token: CSRF_TOKEN,
        }),
        PROD_AXIOS_INSTANCE.post(`/api/sales/v2/orglist/${orgId}/c`, {
          data: { page: 1, limit: 50 },
          _token: CSRF_TOKEN,
        }),
        PROD_AXIOS_INSTANCE.get(`/api/sales/v2/orglist/${orgId}`),
      ]);

      return {
        notes: notesRes.data?.content?.notes || [],
        projects: projectsRes.data?.content?.projects || [],
        calls: callsRes.data?.content?.calls || [],
        main: mainRes.data?.content || null,
        updatedAt: mainRes.data?.content?.updated_at || Date.now(),
      };
    } else {
      // DEV MODE - возвращаем моковые данные
      return {
        notes: [],
        projects: [],
        calls: [],
        main: null,
        updatedAt: Date.now(),
      };
    }
  }, [orgId]);

  // ===================== ХУК ФОРМ =====================
  
  const {
    forms,
    changedTabs,
    hasChanges,
    setOriginalData,
    handleDataChange,
    getPayload,
    resetAllForms,
    commitChanges,
    
    // Draft
    syncStatus,
    isOnline,
    hasDraft,
    draftData,
    serverData,
    diffResult,
    isOfflineMode,
    initializeData,
    applyDraft,
    applySelectedChanges,
    discardDraft,
    
    // Logging
    logAction,
  } = useOrgPageForms({
    orgId,
    loadServerDataFn: loadServerData,
    onDraftConflict: ({ draft, serverData, comparison }) => {
      // Показываем баннер или модалку при обнаружении конфликта
      console.log('[OrgPage] Обнаружен конфликт черновика', comparison);
    },
  });

  // ===================== ИНИЦИАЛИЗАЦИЯ =====================
  
  useEffect(() => {
    if (orgId) {
      initializeData();
    }
  }, [orgId, initializeData]);

  // ===================== СОХРАНЕНИЕ =====================
  
  const handleSave = async () => {
    setSaving(true);
    logAction('save_started');
    
    try {
      const payload = getPayload();
      
      if (Object.keys(payload).length === 0) {
        message.info('Нет изменений для сохранения');
        setSaving(false);
        return;
      }
      
      console.log('📤 Payload:', payload);
      
      if (PRODMODE) {
        const response = await PROD_AXIOS_INSTANCE.put(
          `/api/sales/v2/updateorglist/${orgId}`,
          { data: payload, _token: CSRF_TOKEN }
        );
        
        if (response.status === 200) {
          message.success('Данные сохранены');
          await commitChanges();
          logAction('save_success');
        } else {
          message.error(response.data?.message || 'Ошибка сохранения');
          logAction('save_error', { error: response.data?.message });
        }
      } else {
        // DEV MODE
        console.log('🧪 DEV: Payload', payload);
        await new Promise(r => setTimeout(r, 1000));
        message.success('DEV: Сохранено');
        await commitChanges();
      }
    } catch (error) {
      console.error('Ошибка:', error);
      message.error(error.message || 'Ошибка сохранения');
      logAction('save_error', { error: error.message });
    } finally {
      setSaving(false);
    }
  };

  // ===================== ОТМЕНА =====================
  
  const handleDiscard = () => {
    resetAllForms();
    setEditMode(false);
    logAction('changes_discarded');
  };

  const handleCloseEdit = () => {
    if (hasChanges) {
      Modal.confirm({
        title: 'Отменить изменения?',
        content: 'Несохранённые данные будут потеряны',
        okText: 'Да, отменить',
        cancelText: 'Нет',
        onOk: handleDiscard,
      });
    } else {
      setEditMode(false);
    }
  };

  // ===================== DRAFT HANDLERS =====================
  
  const handleLoadDraft = () => {
    applyDraft();
    setEditMode(true);
    logAction('draft_loaded');
  };

  const handleShowDiff = () => {
    setDiffModalVisible(true);
    logAction('draft_diff_opened');
  };

  const handleDiscardDraft = async () => {
    await discardDraft();
    logAction('draft_discarded');
  };

  const handleApplyAllFromDraft = () => {
    applyDraft();
    setDiffModalVisible(false);
    setEditMode(true);
    logAction('draft_applied_all');
  };

  const handleApplySelectedFromDraft = (selectedChanges) => {
    applySelectedChanges(selectedChanges);
    setDiffModalVisible(false);
    setEditMode(true);
    logAction('draft_applied_selected', { changes: selectedChanges });
  };

  // ===================== ТАБЫ =====================
  
  const handleTabChange = (tabKey) => {
    setActiveTab(tabKey);
    searchParams.set('tab', tabKey);
    setSearchParams(searchParams);
    logAction('tab_changed', { tab: tabKey });
  };

  // ===================== РЕНДЕР =====================
  
  return (
    <div className="app-page">
      <div className="sa-orgpage-body sa-mw-1400">
        
        {/* Header */}
        <Affix offsetTop={0}>
          <div className="sa-orgpage-header">
            <div className="sa-flex-space">
              <div className="sa-orgpage-header-title">
                <Space>
                  Паспорт организации ({orgId}) / {TAB_CONFIG.find(t => t.key === activeTab)?.label}
                  
                  {/* Индикатор сети */}
                  {!isOnline && (
                    <Tooltip title="Нет соединения">
                      <CloudOutlined style={{ color: '#ff4d4f' }} />
                    </Tooltip>
                  )}
                  {isOfflineMode && (
                    <Tag color="orange">Офлайн режим</Tag>
                  )}
                </Space>
              </div>
              
              <div className="sa-orp-menu">
                {TAB_CONFIG.map(tab => (
                  <div
                    key={tab.key}
                    className={`sa-orp-menu-button 
                      ${activeTab === tab.key ? 'active' : ''}
                      ${changedTabs[tab.key] ? 'sa-mite-has-some' : ''}
                    `}
                    onClick={() => handleTabChange(tab.key)}
                  >
                    {tab.label}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Affix>

        {/* Sub-header */}
        <Affix offsetTop={36}>
          <div className="sa-orgpage-sub-header sa-flex-space">
            <div className="sa-orgpage-sub-name">{orgName || '...'}</div>
            <div className="sa-flex sa-orgpage-sub-control">
              {editMode && hasChanges && (
                <Tooltip title="Не забудьте сохранить">
                  <Tag color="red-inverse">Несохранённые данные</Tag>
                </Tooltip>
              )}
              
              {editMode ? (
                <>
                  <Button
                    type="primary"
                    icon={saving ? <LoadingOutlined /> : <ClipboardDocumentCheckIcon height={16} />}
                    onClick={handleSave}
                    disabled={!hasChanges || saving || !isOnline}
                    loading={saving}
                  >
                    {saving ? 'Сохраняю...' : 'Сохранить'}
                  </Button>
                  <Button
                    icon={<XMarkIcon height={16} />}
                    onClick={handleCloseEdit}
                  >
                    Закрыть
                  </Button>
                </>
              ) : (
                <Button 
                  icon={<PencilIcon height={16} />} 
                  onClick={() => setEditMode(true)}
                >
                  Редактировать
                </Button>
              )}
            </div>
          </div>
        </Affix>

        {/* Draft Status Banner */}
        <DraftStatusBanner
          syncStatus={syncStatus}
          draftData={draftData}
          onLoadDraft={handleLoadDraft}
          onShowDiff={handleShowDiff}
          onDiscardDraft={handleDiscardDraft}
        />

        {/* Контент */}
        <div className="sa-outlet-body">
          
          {/* Загрузка */}
          {syncStatus === SYNC_STATUS.LOADING && (
            <div style={{ textAlign: 'center', padding: 40 }}>
              <Spin size="large" />
              <div style={{ marginTop: 16 }}>Загрузка данных...</div>
            </div>
          )}
          
          {syncStatus !== SYNC_STATUS.LOADING && (
            <>
              {activeTab === 'b' && (
                <OrgListModalBillsTab 
                  data={{ id: orgId }} 
                  environment="editor" 
                  org_name={orgName} 
                />
              )}
              
              {activeTab === 'o' && (
                <OrgListModalOffersTab 
                  data={{ id: orgId }} 
                  environment="editor" 
                  org_name={orgName} 
                />
              )}
              
              {activeTab === 'm' && <div>TODO: MainTabForm</div>}
              
              {/* ✅ ПРОЕКТЫ */}
              <ProjectsTabForm
                form={forms.projects}
                orgId={orgId}
                editMode={editMode}
                isActive={activeTab === 'p'}
                userdata={userdata}
                selects={selects}
                orgContacts={orgContacts}
                onDataChange={handleDataChange}
                onOriginalDataLoaded={(data) => setOriginalData('p', data)}
              />
              
              {activeTab === 'c' && <div>TODO: CallsTabForm</div>}
              
              {/* ✅ ЗАМЕТКИ */}
              <NotesTabForm
                form={forms.notes}
                orgId={orgId}
                editMode={editMode}
                isActive={activeTab === 'n'}
                userdata={userdata}
                onDataChange={handleDataChange}
                onOriginalDataLoaded={(data) => setOriginalData('n', data)}
              />
              
              {activeTab === 'h' && (
                <OrgListModalHistoryTab 
                  data={{ id: orgId }} 
                  environment="editor" 
                />
              )}
            </>
          )}
        </div>
      </div>

      {/* Модальное окно сравнения черновиков */}
      <DraftDiffModal
        visible={diffModalVisible}
        onClose={() => setDiffModalVisible(false)}
        diffResult={diffResult}
        draftData={draftData}
        serverData={serverData}
        onApplyAll={handleApplyAllFromDraft}
        onApplySelected={handleApplySelectedFromDraft}
        onDiscard={async () => {
          await handleDiscardDraft();
          setDiffModalVisible(false);
        }}
      />
    </div>
  );
};

// Добавляем Space для использования внутри
const Space = ({ children, ...props }) => (
  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }} {...props}>
    {children}
  </span>
);

export default OrgPage;
