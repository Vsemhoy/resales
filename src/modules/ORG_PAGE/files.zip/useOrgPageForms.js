/**
 * useOrgPageForms.js - Централизованное управление формами OrgPage
 * 
 * Включает:
 * - Управление формами всех вкладок
 * - Отслеживание изменений
 * - Интеграция с DraftManager (черновики)
 * - Интеграция с FormLogger (логирование)
 * - Сбор данных для сохранения
 */

import { useCallback, useRef, useState, useEffect } from 'react';
import { Form, message } from 'antd';
import dayjs from 'dayjs';

import draftManager from './DraftManager';
import { useDraftSync, SYNC_STATUS } from './useDraftSync';

// Попробуем импортировать FormLogger (может быть не установлен)
let formLogger = null;
try {
  formLogger = require('./FormLogger').default;
} catch (e) {
  console.warn('[useOrgPageForms] FormLogger не найден');
}

/**
 * Сравнивает два значения с учётом dayjs
 */
const isEqual = (a, b) => {
  if (dayjs.isDayjs(a) && dayjs.isDayjs(b)) {
    return a.valueOf() === b.valueOf();
  }
  if (dayjs.isDayjs(a) || dayjs.isDayjs(b)) {
    return false;
  }
  if (Array.isArray(a) && Array.isArray(b)) {
    return JSON.stringify(a) === JSON.stringify(b);
  }
  return a === b;
};

/**
 * Хук для управления формами OrgPage
 */
export const useOrgPageForms = ({
  orgId,
  loadServerDataFn,  // Функция загрузки данных с сервера
  onDraftConflict,   // Callback при обнаружении конфликта черновика
}) => {
  // ===================== ИНСТАНСЫ ФОРМ =====================
  const [notesForm] = Form.useForm();
  const [projectsForm] = Form.useForm();
  const [callsForm] = Form.useForm();
  const [mainForm] = Form.useForm();

  const forms = {
    notes: notesForm,
    projects: projectsForm,
    calls: callsForm,
    main: mainForm,
  };

  // ===================== СОСТОЯНИЯ =====================
  
  // Оригинальные данные (для сравнения при сохранении)
  const originalDataRef = useRef({
    notes: [],
    projects: [],
    calls: [],
    main: null,
  });

  // Индикаторы изменений по вкладкам
  const [changedTabs, setChangedTabs] = useState({
    m: false, // main
    p: false, // projects
    c: false, // calls
    n: false, // notes
  });

  // Есть ли несохранённые изменения
  const hasChanges = Object.values(changedTabs).some(Boolean);

  // ===================== ИНТЕГРАЦИЯ С DRAFT =====================
  
  const {
    syncStatus,
    isOnline,
    hasDraft,
    draftData,
    serverData,
    diffResult,
    isOfflineMode,
    initializeData,
    saveDraft,
    scheduleDraftSave,
    applyDraft,
    applySelectedChanges,
    discardDraft,
    collectFormsData,
  } = useDraftSync({
    orgId,
    forms,
    loadServerData: loadServerDataFn,
    onDraftConflict,
  });

  // ===================== УСТАНОВКА ОРИГИНАЛЬНЫХ ДАННЫХ =====================

  /**
   * Сохраняет оригинальные данные при загрузке с сервера
   */
  const setOriginalData = useCallback((tabKey, data) => {
    switch (tabKey) {
      case 'n':
        originalDataRef.current.notes = JSON.parse(JSON.stringify(data));
        break;
      case 'p':
        originalDataRef.current.projects = JSON.parse(JSON.stringify(data));
        break;
      case 'c':
        originalDataRef.current.calls = JSON.parse(JSON.stringify(data));
        break;
      case 'm':
        originalDataRef.current.main = JSON.parse(JSON.stringify(data));
        break;
    }
  }, []);

  // ===================== ОТСЛЕЖИВАНИЕ ИЗМЕНЕНИЙ =====================

  /**
   * Callback от дочерних форм при изменении данных
   */
  const handleDataChange = useCallback((tabKey, hasChanges) => {
    setChangedTabs(prev => {
      if (prev[tabKey] === hasChanges) return prev;
      return { ...prev, [tabKey]: hasChanges };
    });

    // Запускаем автосохранение черновика
    if (hasChanges) {
      scheduleDraftSave();
    }

    // Логируем изменение (если FormLogger доступен)
    if (formLogger && hasChanges) {
      logFieldChange(tabKey);
    }
  }, [scheduleDraftSave]);

  // ===================== ЛОГИРОВАНИЕ =====================

  /**
   * Логирует изменение поля формы
   */
  const logFieldChange = useCallback((tabKey) => {
    if (!formLogger) return;

    const form = forms[tabKey === 'n' ? 'notes' : 
                       tabKey === 'p' ? 'projects' :
                       tabKey === 'c' ? 'calls' : 'main'];
    
    if (!form) return;

    const values = form.getFieldsValue();
    
    formLogger.log('form_change', {
      orgId,
      tab: tabKey,
      timestamp: Date.now(),
    });

    // Сохраняем снэпшот если включено
    if (formLogger.getSettings().saveSnapshots) {
      formLogger.log('form_snapshot', {
        orgId,
        tab: tabKey,
        data: values,
        timestamp: Date.now(),
      });
    }
  }, [orgId, forms]);

  /**
   * Логирует действие пользователя
   */
  const logAction = useCallback((action, details = {}) => {
    if (!formLogger) return;

    formLogger.log(action, {
      orgId,
      ...details,
      timestamp: Date.now(),
    });
  }, [orgId]);

  // ===================== СБОР ДАННЫХ ДЛЯ СОХРАНЕНИЯ =====================

  /**
   * Собирает изменённые данные со всех форм
   */
  const collectAllChanges = useCallback(() => {
    const result = {
      notes: [],
      projects: [],
      calls: [],
      main: null,
    };

    // Заметки
    if (changedTabs.n) {
      result.notes = collectNotesChanges(
        notesForm.getFieldsValue(),
        originalDataRef.current.notes
      );
    }

    // Проекты
    if (changedTabs.p) {
      result.projects = collectProjectsChanges(
        projectsForm.getFieldsValue(),
        originalDataRef.current.projects
      );
    }

    // Звонки
    if (changedTabs.c) {
      result.calls = collectCallsChanges(
        callsForm.getFieldsValue(),
        originalDataRef.current.calls
      );
    }

    // Основная информация
    if (changedTabs.m) {
      result.main = collectMainChanges(
        mainForm.getFieldsValue(),
        originalDataRef.current.main
      );
    }

    return result;
  }, [changedTabs, notesForm, projectsForm, callsForm, mainForm]);

  /**
   * Возвращает payload для отправки на сервер
   */
  const getPayload = useCallback(() => {
    const changes = collectAllChanges();
    
    const payload = {};
    
    if (changes.notes.length > 0) {
      payload.notes = changes.notes;
    }
    if (changes.projects.length > 0) {
      payload.projects = changes.projects;
    }
    if (changes.calls.length > 0) {
      payload.calls = changes.calls;
    }
    if (changes.main) {
      payload.main = changes.main;
    }

    return payload;
  }, [collectAllChanges]);

  // ===================== СБРОС =====================

  /**
   * Сбрасывает все формы к оригинальным данным
   */
  const resetAllForms = useCallback(() => {
    notesForm.setFieldsValue({
      existingNotes: JSON.parse(JSON.stringify(originalDataRef.current.notes)),
      newNotes: [],
    });
    
    projectsForm.setFieldsValue({
      existingProjects: JSON.parse(JSON.stringify(originalDataRef.current.projects)),
      newProjects: [],
    });
    
    callsForm.setFieldsValue({
      existingCalls: JSON.parse(JSON.stringify(originalDataRef.current.calls)),
      newCalls: [],
    });
    
    if (originalDataRef.current.main) {
      mainForm.setFieldsValue(JSON.parse(JSON.stringify(originalDataRef.current.main)));
    }

    setChangedTabs({ m: false, p: false, c: false, n: false });
    
    logAction('form_reset');
  }, [notesForm, projectsForm, callsForm, mainForm, logAction]);

  /**
   * Сбрасывает индикаторы изменений
   */
  const clearChangedFlags = useCallback(() => {
    setChangedTabs({ m: false, p: false, c: false, n: false });
  }, []);

  /**
   * Обновляет оригинальные данные текущими (после успешного сохранения)
   */
  const commitChanges = useCallback(async () => {
    const notesValues = notesForm.getFieldsValue();
    const projectsValues = projectsForm.getFieldsValue();
    const callsValues = callsForm.getFieldsValue();
    const mainValues = mainForm.getFieldsValue();

    // Объединяем new + existing
    originalDataRef.current.notes = [
      ...(notesValues.newNotes || []),
      ...(notesValues.existingNotes || []),
    ].filter(item => item && !item.deleted);

    originalDataRef.current.projects = [
      ...(projectsValues.newProjects || []),
      ...(projectsValues.existingProjects || []),
    ].filter(item => item && !item.deleted);

    originalDataRef.current.calls = [
      ...(callsValues.newCalls || []),
      ...(callsValues.existingCalls || []),
    ].filter(item => item && !item.deleted);

    originalDataRef.current.main = mainValues;

    clearChangedFlags();

    // Удаляем черновик после успешного сохранения
    if (orgId) {
      await draftManager.deleteDraft(orgId);
    }

    logAction('form_saved');
  }, [notesForm, projectsForm, callsForm, mainForm, clearChangedFlags, orgId, logAction]);

  // ===================== ВОЗВРАЩАЕМОЕ API =====================

  return {
    // Формы
    forms,
    
    // Состояние изменений
    changedTabs,
    hasChanges,
    
    // Методы работы с формами
    setOriginalData,
    handleDataChange,
    getPayload,
    resetAllForms,
    clearChangedFlags,
    commitChanges,
    
    // Draft синхронизация
    syncStatus,
    isOnline,
    hasDraft,
    draftData,
    serverData,
    diffResult,
    isOfflineMode,
    initializeData,
    saveDraft,
    applyDraft,
    applySelectedChanges,
    discardDraft,
    
    // Логирование
    logAction,
    
    // Ref для прямого доступа
    originalDataRef,
  };
};


// =============================================================================
// ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ СБОРА ДАННЫХ
// =============================================================================

const collectNotesChanges = (formValues, originalData) => {
  const result = [];
  
  const newNotes = formValues.newNotes || [];
  newNotes.forEach(note => {
    if (note && !note.deleted) {
      result.push({
        ...note,
        command: 'create',
        date: note.date ? dayjs(note.date).format('DD.MM.YYYY HH:mm:ss') : null,
      });
    }
  });
  
  const existingNotes = formValues.existingNotes || [];
  existingNotes.forEach((note) => {
    if (!note) return;
    
    const original = originalData.find(o => o.id === note.id);
    if (!original) return;
    
    const isChanged = 
      note.theme !== original.theme ||
      note.notes !== original.notes ||
      note.deleted !== original.deleted;
    
    if (isChanged) {
      result.push({
        ...note,
        command: note.deleted ? 'delete' : 'update',
        date: note.date ? dayjs(note.date).format('DD.MM.YYYY HH:mm:ss') : null,
      });
    }
  });
  
  return result;
};

const collectProjectsChanges = (formValues, originalData) => {
  const result = [];
  
  const newProjects = formValues.newProjects || [];
  newProjects.forEach(project => {
    if (project && !project.deleted) {
      result.push({
        ...project,
        command: 'create',
        date: project.date ? dayjs(project.date).format('DD.MM.YYYY HH:mm:ss') : null,
        date_end: project.date_end ? dayjs(project.date_end).format('DD.MM.YYYY HH:mm:ss') : null,
      });
    }
  });
  
  const existingProjects = formValues.existingProjects || [];
  existingProjects.forEach((project) => {
    if (!project) return;
    
    const original = originalData.find(o => o.id === project.id);
    if (!original) return;
    
    const fieldsToCompare = [
      'name', 'equipment', 'customer', 'address', 'stage', 
      'contactperson', 'cost', 'bonus', 'comment', 'typepaec',
      'erector_id', 'deleted'
    ];
    
    const isChanged = fieldsToCompare.some(field => !isEqual(project[field], original[field])) ||
      !isEqual(project.date, dayjs(original.date)) ||
      !isEqual(project.date_end, dayjs(original.date_end));
    
    if (isChanged) {
      result.push({
        ...project,
        command: project.deleted ? 'delete' : 'update',
        date: project.date ? dayjs(project.date).format('DD.MM.YYYY HH:mm:ss') : null,
        date_end: project.date_end ? dayjs(project.date_end).format('DD.MM.YYYY HH:mm:ss') : null,
      });
    }
  });
  
  return result;
};

const collectCallsChanges = (formValues, originalData) => {
  // TODO: Реализовать после создания CallsTabForm
  return [];
};

const collectMainChanges = (formValues, originalData) => {
  // TODO: Реализовать после создания MainTabForm
  return null;
};


export default useOrgPageForms;
