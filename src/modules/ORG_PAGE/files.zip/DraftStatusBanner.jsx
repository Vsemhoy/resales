/**
 * DraftStatusBanner.jsx - Баннер статуса черновика
 * 
 * Отображает текущий статус синхронизации:
 * - Найден черновик
 * - Офлайн режим
 * - Переподключение
 */

import React from 'react';
import { Button, Space, Spin } from 'antd';
import { 
  CloudOffOutlined, 
  CloudSyncOutlined, 
  FileTextOutlined,
  SyncOutlined,
  CheckCircleOutlined,
  ExclamationCircleOutlined,
} from '@ant-design/icons';
import dayjs from 'dayjs';

import { SYNC_STATUS } from './useDraftSync';
import './style/draft-diff-modal.css';

const DraftStatusBanner = ({
  syncStatus,
  draftData,
  onLoadDraft,
  onShowDiff,
  onDiscardDraft,
}) => {
  // Не показываем баннер для обычных состояний
  if (syncStatus === SYNC_STATUS.IDLE || syncStatus === SYNC_STATUS.LOADING) {
    return null;
  }

  // Конфиг для разных статусов
  const statusConfig = {
    [SYNC_STATUS.DRAFT_FOUND]: {
      className: 'draft-found',
      icon: <FileTextOutlined />,
      message: `Найден несохранённый черновик от ${formatDate(draftData?.updatedAt)}`,
      actions: [
        { key: 'load', label: 'Загрузить', onClick: onLoadDraft },
        { key: 'diff', label: 'Показать различия', onClick: onShowDiff },
        { key: 'discard', label: 'Удалить', onClick: onDiscardDraft, danger: true },
      ],
    },
    [SYNC_STATUS.OFFLINE]: {
      className: 'offline',
      icon: <CloudOffOutlined />,
      message: 'Нет соединения с сервером. Данные недоступны.',
      actions: draftData ? [
        { key: 'load', label: 'Загрузить последний черновик', onClick: onLoadDraft },
      ] : [],
    },
    [SYNC_STATUS.OFFLINE_DRAFT]: {
      className: 'offline-draft',
      icon: <CloudOffOutlined />,
      message: 'Вы работаете в офлайн режиме. Данные будут сохранены при восстановлении соединения.',
      actions: [],
    },
    [SYNC_STATUS.RECONNECTING]: {
      className: 'reconnecting',
      icon: <SyncOutlined spin />,
      message: 'Попытка подключения к серверу...',
      actions: [],
    },
    [SYNC_STATUS.RECONNECTED]: {
      className: 'reconnected',
      icon: <CheckCircleOutlined />,
      message: 'Соединение восстановлено!',
      actions: [],
    },
    [SYNC_STATUS.SAVING_DRAFT]: {
      className: 'saving',
      icon: <Spin size="small" />,
      message: 'Сохранение черновика...',
      actions: [],
    },
    [SYNC_STATUS.ERROR]: {
      className: 'error',
      icon: <ExclamationCircleOutlined />,
      message: 'Ошибка загрузки данных',
      actions: draftData ? [
        { key: 'load', label: 'Загрузить черновик', onClick: onLoadDraft },
      ] : [],
    },
  };

  const config = statusConfig[syncStatus];
  
  if (!config) return null;

  return (
    <div className={`draft-status-banner ${config.className}`}>
      <div className="draft-status-banner-content">
        {config.icon}
        <span>{config.message}</span>
      </div>
      
      {config.actions.length > 0 && (
        <div className="draft-status-banner-actions">
          <Space size="small">
            {config.actions.map(action => (
              <Button
                key={action.key}
                size="small"
                type={action.key === 'load' ? 'primary' : 'default'}
                danger={action.danger}
                onClick={action.onClick}
              >
                {action.label}
              </Button>
            ))}
          </Space>
        </div>
      )}
    </div>
  );
};

// Форматирование даты
function formatDate(timestamp) {
  if (!timestamp) return '';
  return dayjs(timestamp).format('DD.MM.YYYY HH:mm');
}

export default DraftStatusBanner;
