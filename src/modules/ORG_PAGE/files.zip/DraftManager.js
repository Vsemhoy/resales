/**
 * DraftManager.js - Менеджер черновиков для OrgPage
 * 
 * Сохраняет черновики форм в IndexedDB для:
 * - Работы при отсутствии интернета
 * - Восстановления несохранённых данных
 * 
 * Структура черновика:
 * {
 *   id: 'org_123',           // orgId как ключ
 *   orgId: 123,
 *   updatedAt: timestamp,    // Время последнего изменения
 *   serverUpdatedAt: ts,     // Время данных с сервера (для сравнения)
 *   data: {
 *     notes: { newNotes: [], existingNotes: [] },
 *     projects: { newProjects: [], existingProjects: [] },
 *     calls: { newCalls: [], existingCalls: [] },
 *     main: { ... }
 *   }
 * }
 */

const DB_NAME = 'OrgPageDrafts';
const DB_VERSION = 1;
const STORE_NAME = 'drafts';

class DraftManager {
  constructor() {
    this.db = null;
    this.isReady = false;
    this._initPromise = null;
  }

  // ===================== ИНИЦИАЛИЗАЦИЯ =====================

  async init() {
    if (this.isReady) return;
    if (this._initPromise) return this._initPromise;

    this._initPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onerror = () => {
        console.error('[DraftManager] Ошибка открытия БД:', request.error);
        reject(request.error);
      };

      request.onsuccess = () => {
        this.db = request.result;
        this.isReady = true;
        console.log('[DraftManager] БД готова');
        resolve();
      };

      request.onupgradeneeded = (event) => {
        const db = event.target.result;

        if (!db.objectStoreNames.contains(STORE_NAME)) {
          const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
          store.createIndex('orgId', 'orgId', { unique: true });
          store.createIndex('updatedAt', 'updatedAt', { unique: false });
          console.log('[DraftManager] Store создан');
        }
      };
    });

    return this._initPromise;
  }

  async _ensureReady() {
    if (!this.isReady) {
      await this.init();
    }
  }

  // ===================== CRUD ОПЕРАЦИИ =====================

  /**
   * Сохраняет черновик
   * @param {number} orgId - ID организации
   * @param {object} data - Данные форм
   * @param {number} serverUpdatedAt - Timestamp данных с сервера (опционально)
   */
  async saveDraft(orgId, data, serverUpdatedAt = null) {
    await this._ensureReady();

    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([STORE_NAME], 'readwrite');
      const store = transaction.objectStore(STORE_NAME);

      const draft = {
        id: `org_${orgId}`,
        orgId,
        updatedAt: Date.now(),
        serverUpdatedAt,
        data: this._serializeData(data),
      };

      const request = store.put(draft);

      request.onsuccess = () => {
        console.log(`[DraftManager] Драфт сохранён для org_${orgId}`);
        resolve(draft);
      };

      request.onerror = () => {
        console.error('[DraftManager] Ошибка сохранения:', request.error);
        reject(request.error);
      };
    });
  }

  /**
   * Получает черновик по orgId
   * @param {number} orgId - ID организации
   * @returns {object|null} - Черновик или null
   */
  async getDraft(orgId) {
    await this._ensureReady();

    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([STORE_NAME], 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.get(`org_${orgId}`);

      request.onsuccess = () => {
        const draft = request.result;
        if (draft) {
          draft.data = this._deserializeData(draft.data);
        }
        resolve(draft || null);
      };

      request.onerror = () => {
        console.error('[DraftManager] Ошибка чтения:', request.error);
        reject(request.error);
      };
    });
  }

  /**
   * Удаляет черновик
   * @param {number} orgId - ID организации
   */
  async deleteDraft(orgId) {
    await this._ensureReady();

    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([STORE_NAME], 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.delete(`org_${orgId}`);

      request.onsuccess = () => {
        console.log(`[DraftManager] Драфт удалён для org_${orgId}`);
        resolve();
      };

      request.onerror = () => {
        console.error('[DraftManager] Ошибка удаления:', request.error);
        reject(request.error);
      };
    });
  }

  /**
   * Проверяет наличие черновика
   * @param {number} orgId - ID организации
   * @returns {boolean}
   */
  async hasDraft(orgId) {
    const draft = await this.getDraft(orgId);
    return draft !== null;
  }

  /**
   * Получает список всех черновиков
   * @returns {Array}
   */
  async getAllDrafts() {
    await this._ensureReady();

    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([STORE_NAME], 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.getAll();

      request.onsuccess = () => {
        const drafts = request.result.map(draft => ({
          ...draft,
          data: this._deserializeData(draft.data),
        }));
        resolve(drafts);
      };

      request.onerror = () => {
        reject(request.error);
      };
    });
  }

  /**
   * Очищает старые черновики (старше N дней)
   * @param {number} maxAgeDays - Максимальный возраст в днях
   */
  async cleanupOldDrafts(maxAgeDays = 30) {
    await this._ensureReady();

    const cutoffTime = Date.now() - (maxAgeDays * 24 * 60 * 60 * 1000);

    return new Promise((resolve, reject) => {
      const transaction = this.db.transaction([STORE_NAME], 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const index = store.index('updatedAt');
      const range = IDBKeyRange.upperBound(cutoffTime);

      const request = index.openCursor(range);
      let deletedCount = 0;

      request.onsuccess = (event) => {
        const cursor = event.target.result;
        if (cursor) {
          cursor.delete();
          deletedCount++;
          cursor.continue();
        } else {
          console.log(`[DraftManager] Удалено старых драфтов: ${deletedCount}`);
          resolve(deletedCount);
        }
      };

      request.onerror = () => {
        reject(request.error);
      };
    });
  }

  // ===================== СРАВНЕНИЕ ДАННЫХ =====================

  /**
   * Сравнивает черновик с данными сервера
   * @param {object} draftData - Данные черновика
   * @param {object} serverData - Данные с сервера
   * @returns {object} - Результат сравнения
   */
  compareDraftWithServer(draftData, serverData) {
    const result = {
      hasDifferences: false,
      tabs: {},
    };

    const tabKeys = ['notes', 'projects', 'calls', 'main'];

    for (const tabKey of tabKeys) {
      const draftTab = draftData?.[tabKey];
      const serverTab = serverData?.[tabKey];

      if (!draftTab && !serverTab) continue;

      const tabDiff = this._compareTabData(tabKey, draftTab, serverTab);
      
      if (tabDiff.hasDifferences) {
        result.hasDifferences = true;
        result.tabs[tabKey] = tabDiff;
      }
    }

    return result;
  }

  /**
   * Сравнивает данные одной вкладки
   */
  _compareTabData(tabKey, draftTab, serverTab) {
    if (tabKey === 'main') {
      return this._compareMainData(draftTab, serverTab);
    }

    // Для списочных вкладок (notes, projects, calls)
    const result = {
      hasDifferences: false,
      added: [],      // Новые записи в драфте
      modified: [],   // Изменённые записи
      deleted: [],    // Удалённые в драфте
      unchanged: [],  // Без изменений
    };

    const newKey = `new${tabKey.charAt(0).toUpperCase() + tabKey.slice(1)}`;
    const existingKey = `existing${tabKey.charAt(0).toUpperCase() + tabKey.slice(1)}`;

    // Новые записи из драфта
    const draftNew = draftTab?.[newKey] || [];
    if (draftNew.length > 0) {
      result.hasDifferences = true;
      result.added = draftNew.filter(item => !item.deleted);
    }

    // Существующие записи
    const draftExisting = draftTab?.[existingKey] || [];
    const serverExisting = serverTab || [];

    // Создаём карту серверных данных
    const serverMap = new Map();
    serverExisting.forEach(item => {
      if (item?.id) serverMap.set(item.id, item);
    });

    // Сравниваем каждую запись драфта
    draftExisting.forEach(draftItem => {
      if (!draftItem?.id) return;

      const serverItem = serverMap.get(draftItem.id);

      if (!serverItem) {
        // Записи нет на сервере (странно, но возможно)
        result.added.push(draftItem);
        result.hasDifferences = true;
        return;
      }

      // Сравниваем поля
      const changes = this._compareItems(draftItem, serverItem, tabKey);
      
      if (changes.length > 0) {
        result.hasDifferences = true;
        result.modified.push({
          id: draftItem.id,
          draft: draftItem,
          server: serverItem,
          changes,
        });
      } else {
        result.unchanged.push(draftItem);
      }
    });

    return result;
  }

  /**
   * Сравнивает две записи и возвращает список изменений
   */
  _compareItems(draftItem, serverItem, tabKey) {
    const changes = [];
    
    // Поля для сравнения в зависимости от типа
    const fieldsMap = {
      notes: ['theme', 'notes', 'deleted'],
      projects: ['name', 'equipment', 'customer', 'address', 'stage', 
                 'contactperson', 'cost', 'bonus', 'comment', 'typepaec',
                 'erector_id', 'date', 'date_end', 'deleted'],
      calls: ['theme', 'result', 'date', 'type', 'deleted'],
    };

    const fields = fieldsMap[tabKey] || [];

    fields.forEach(field => {
      const draftValue = this._normalizeValue(draftItem[field]);
      const serverValue = this._normalizeValue(serverItem[field]);

      if (draftValue !== serverValue) {
        changes.push({
          field,
          draftValue: draftItem[field],
          serverValue: serverItem[field],
        });
      }
    });

    return changes;
  }

  /**
   * Сравнивает данные основной вкладки
   */
  _compareMainData(draftMain, serverMain) {
    // TODO: Реализовать для MainTabForm
    return { hasDifferences: false };
  }

  /**
   * Нормализует значение для сравнения
   */
  _normalizeValue(value) {
    if (value === null || value === undefined) return '';
    if (value instanceof Date) return value.getTime();
    if (typeof value === 'object' && value.$d) {
      // dayjs объект
      return new Date(value.$d).getTime();
    }
    if (typeof value === 'object') return JSON.stringify(value);
    return String(value);
  }

  // ===================== СЕРИАЛИЗАЦИЯ =====================

  /**
   * Сериализует данные для хранения (конвертирует dayjs в строки)
   */
  _serializeData(data) {
    return JSON.parse(JSON.stringify(data, (key, value) => {
      // Конвертируем dayjs в ISO строку
      if (value && typeof value === 'object' && value.$d) {
        return { __type: 'dayjs', value: value.toISOString() };
      }
      return value;
    }));
  }

  /**
   * Десериализует данные (конвертирует строки обратно в dayjs)
   */
  _deserializeData(data) {
    if (!data) return data;
    
    // Импортируем dayjs динамически или используем глобальный
    const dayjs = window.dayjs || require('dayjs');
    
    return JSON.parse(JSON.stringify(data), (key, value) => {
      if (value && typeof value === 'object' && value.__type === 'dayjs') {
        return dayjs(value.value);
      }
      return value;
    });
  }

  // ===================== СТАТУС СЕТИ =====================

  /**
   * Проверяет доступность сети
   */
  isOnline() {
    return navigator.onLine;
  }

  /**
   * Подписка на изменение статуса сети
   */
  onNetworkChange(callback) {
    const handleOnline = () => callback(true);
    const handleOffline = () => callback(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Возвращаем функцию отписки
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }
}

// Синглтон
const draftManager = new DraftManager();

export default draftManager;
export { DraftManager };
